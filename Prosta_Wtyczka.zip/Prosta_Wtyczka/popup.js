function setBackgroundColor(color) {
  document.body.style.backgroundColor = color;
}

function getRandomColor() {
  const hue = Math.floor(Math.random() * 360);
  return `hsl(${hue}, 70%, 80%)`;
}

async function changeColor(colorSupplier) {
  try {

    const tabs = await browser.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    
    if (!tab || !tab.id) return;

    if (tab.url.startsWith("about:") || tab.url.startsWith("moz-extension:")) {
      alert("Nie można zmienić tła na tej stronie wewnętrznej.");
      return;
    }

    const color = typeof colorSupplier === 'function' ? colorSupplier() : colorSupplier;


    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      func: setBackgroundColor,
      args: [color]
    });
  } catch (error) {
    console.error("Błąd podczas zmiany tła:", error);
  }
}


document.getElementById('btnRandom').addEventListener('click', () => {
  changeColor(getRandomColor);
});

document.getElementById('btnReset').addEventListener('click', () => {
  changeColor('');
});